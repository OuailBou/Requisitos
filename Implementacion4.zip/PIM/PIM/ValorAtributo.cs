﻿using System;
using System.Collections.Generic;

namespace PIM
{
    class ValorAtributo
    {
        public string productoSku;
        public string productoGtin;
        public string atributoNombre;
        public string valor;

        // Constructor
        public ValorAtributo(string productoSku, string productoGtin, string atributoNombre, string valor)
        {
            this.productoSku = productoSku;
            this.productoGtin = productoGtin;
            this.atributoNombre = atributoNombre;
            this.valor = valor;

            // Inserción en la base de datos
            Consulta c = new Consulta();
            string consulta = "INSERT INTO ValorAtributo VALUES ('" + productoSku + "', '" + productoGtin + "', '" + atributoNombre + "', '" + valor + "');";
            c.Insert(consulta);
        }

        public ValorAtributo(string atributoNombre, string valor)
        {
            this.atributoNombre = atributoNombre;
            this.valor = valor;
        }
    }
}