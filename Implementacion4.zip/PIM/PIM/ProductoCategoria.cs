﻿using System;
using System.Collections.Generic;

namespace PIM
{
    class ProductoCategoria
    {
        private string productoSku;
        private string productoGtin;
        private string categoriaNombre;

        // Constructor
        public ProductoCategoria(string productoSku, string productoGtin, string categoriaNombre)
        {
            this.productoSku = productoSku;
            this.productoGtin = productoGtin;
            this.categoriaNombre = categoriaNombre;

            // Inserción en la base de datos
            Consulta c = new Consulta();
            string consulta = "INSERT INTO ProductoCategoria (producto_sku, producto_gtin, categoria_nombre) " +
                              "VALUES ('" + productoSku + "', '" + productoGtin + "', '" + categoriaNombre + "');";
            c.Insert(consulta);
        }
    }
}
