﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PIM
{
    class Producto
    {
        private string sku;
        private string gtin;
        private string nombre;
        private string thumbnail;


        // Constructor
        public Producto(string sku, string gtin, string nombre, string thumbnail)
        {
            Consulta c = new Consulta();
            c.Insert("INSERT INTO Producto VALUES ('" + sku + "', '" + gtin + "', '" + thumbnail + "', '" + nombre + "');");


            this.sku = sku;
            this.gtin = gtin;
            this.nombre = nombre;
            this.thumbnail = thumbnail;
        }

        // Propiedad SKU
        public string SKU
        {
            get { return this.sku; }
            set
            {
                Consulta c = new Consulta();
                string consulta = "UPDATE Producto SET SKU = '" + value + "' WHERE SKU = '" + this.sku + "';";
                c.Update(consulta);
                this.sku = value;
            }
        }

        // Propiedad GTIN
        public string GTIN
        {
            get { return this.gtin; }
            set
            {
                Consulta c = new Consulta();
                string consulta = "UPDATE Producto SET GTIN = '" + value + "' WHERE SKU = '" + this.sku + "';";
                c.Update(consulta);
                this.gtin = value;
            }
        }

        // Propiedad Thumbnail
        public string Thumbnail
        {
            get { return this.thumbnail; }
            set
            {
                Consulta c = new Consulta();
                string consulta = "UPDATE Producto SET thumbnail = '" + value + "' WHERE SKU = '" + this.sku + "';";
                c.Update(consulta);
                this.thumbnail = value;
            }
        }

        // Propiedad Nombre
        public string Nombre
        {
            get { return this.nombre; }
            set
            {
                Consulta c = new Consulta();
                string consulta = "UPDATE Producto SET nombre = '" + value + "' WHERE SKU = '" + this.sku + "';";
                c.Update(consulta);
                this.nombre = value;
            }
        }
    }
}
