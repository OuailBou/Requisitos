﻿using System;
using System.Collections.Generic;

namespace PIM
{
    class Categoria
    {
        private string nombre; // Clave primaria única

        // Constructor
        public Categoria(string nombre)
        {
            // Inserción en la base de datos
            Consulta c = new Consulta();
            c.Insert("INSERT INTO Categoria (nombre) VALUES ('" + nombre + "');");

            this.nombre = nombre;
        }

        public Categoria()
        {
            
        }

        // Método estático para listar todas las categorías
        public static List<Categoria> ListaCategorias()
        {
            Consulta c = new Consulta();
            string consulta = "SELECT nombre FROM Categoria;";

            List<Categoria> listaCategorias = new List<Categoria>();

            // Usamos un foreach para recorrer los resultados y añadir objetos Categoria a la lista
            foreach (object[] tupla in c.Select(consulta))
            {
                string nombre = (string)tupla[0];

                // Crear una nueva categoría con el nombre obtenido
                Categoria categoria = new Categoria();
                categoria.nombre = nombre;
                listaCategorias.Add(categoria);
            }

            return listaCategorias;
        }

        // Propiedad Nombre (Clave primaria)
        public string Nombre
        {
            get { return this.nombre; }
            set
            {
                Consulta c = new Consulta();
                string consulta = "UPDATE Categoria SET nombre = '" + value + "' WHERE nombre = '" + this.nombre + "';";
                c.Update(consulta);
                this.nombre = value;
            }
        }

        public override string ToString()
        {
            return this.nombre;  // Simplemente mostramos el nombre de la categoría
        }
    }
}
