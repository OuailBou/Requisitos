﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PIM
{
    public class Producto
    {
        private string sku;
        private string gtin;
        private string nombre;
        private string thumbnail;


        // Constructor
        public Producto(string sku, string gtin, string nombre, string thumbnail)
        {
            Consulta c = new Consulta();
            c.Insert("INSERT INTO Producto VALUES ('" + sku + "', '" + gtin + "', '" + thumbnail + "', '" + nombre + "');");


            this.sku = sku;
            this.gtin = gtin;
            this.nombre = nombre;
            this.thumbnail = thumbnail;
        }
        public Producto()
        {
            
        }

        public Producto(string sku)
        {
            this.sku = sku;
            Consulta c = new Consulta();
            // Consulta SQL simple
            string query = "SELECT  GTIN, Thumbnail_url, nombre FROM Producto WHERE SKU = '" + sku + "'";

            // Llamar a Consulta() para obtener los resultados
            Object[] a = c.Select(query)[0];
           
            this.gtin = (String)a[0];
            this.thumbnail = (String)a[1];
            this.nombre = (String)a[2];

        }
        public static List<Producto>ListaProductos() {
            Consulta c = new Consulta();
            List<Producto> p = new List<Producto>();
            foreach (Object[] a in c.Select("SELECT * FROM Producto"))
            {
                Producto p1 = new Producto();
                p1.sku = (string)a[0];
                p1.gtin=(string) a [1];
                p1.nombre=(string) a [3];
                p1.thumbnail=(string) a [2];
                p.Add(p1);
            }
            return p;

    }
        public override String ToString()
        {
            return this.sku +" "+  this.gtin + " " +this.nombre + " " + this.thumbnail; 
        }
        public void Borrar()
        {
            Consulta c = new Consulta();
            c.Delete("DELETE FROM Producto WHERE SKU='" + this.sku + "'");
        }


        // Propiedad SKU
        public string SKU
        {
            get { return this.sku; }
            set
            {
                Consulta c = new Consulta();
                string consulta = "UPDATE Producto SET SKU = '" + value + "' WHERE SKU = '" + this.sku + "';";
                c.Update(consulta);
                this.sku = value;
            }
        }

        // Propiedad GTIN
        public string GTIN
        {
            get { return this.gtin; }
            set
            {
                Consulta c = new Consulta();
                string consulta = "UPDATE Producto SET GTIN = '" + value + "' WHERE SKU = '" + this.sku + "';";
                c.Update(consulta);
                this.gtin = value;
            }
        }

        // Propiedad Thumbnail
        public string Thumbnail
        {
            get { return this.thumbnail; }
            set
            {
                Consulta c = new Consulta();
                string consulta = "UPDATE Producto SET thumbnail = '" + value + "' WHERE SKU = '" + this.sku + "';";
                c.Update(consulta);
                this.thumbnail = value;
            }
        }

        // Propiedad Nombre
        public string Nombre
        {
            get { return this.nombre; }
            set
            {
                Consulta c = new Consulta();
                string consulta = "UPDATE Producto SET nombre = '" + value + "' WHERE SKU = '" + this.sku + "';";
                c.Update(consulta);
                this.nombre = value;
            }
        }
    }
}
