﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIM
{
    static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main()
        {

             //Consulta c1 = new Consulta();
             //c1.Insert("INSERT INTO Categoria (nombre) VALUES ('Prueba')");
             // Producto p=new Producto();
             //p.SKU = "001";
             //ValorAtributo.ListarAtributoDeProducto(p);
             //List<Atributo> listaAtributos = Atributo.ListarAtributos();

            //Console.WriteLine("Lista de Atributos:");
            //foreach (Atributo atributo in listaAtributos)
            //{
                // Mostrar cada atributo usando el método ToString
              //  Console.WriteLine(atributo.ToString());
            //}
            //Categoria c = new Categoria("categoria1");
            /*
            foreach(Categoria a in Categoria.ListarCategorias()) {
                Console.WriteLine(a.ToString());
            }

            */

            
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            
            

            // Inicia la aplicación de Windows Forms
            Application.Run(new PantallaPrincipal());
            
        }
    }
}
