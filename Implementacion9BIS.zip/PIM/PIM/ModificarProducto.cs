﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace PIM
{
    public partial class ModificarProducto : Form
    {
        private Producto producto;
        private Dictionary<string, string> valoresModificados = new Dictionary<string, string>(); // Para almacenar los valores modificados

        public ModificarProducto(Producto producto)
        {
            InitializeComponent();
            this.producto = new Producto(producto.SKU);
        }

        private void ModificarProducto_Load(object sender, EventArgs e)
        {
            // Cargar los atributos del producto
            dataGridView1.DataSource = ValorAtributo.ListarAtributoDeProducto(producto);

            // Cargar categorías
            foreach (Categoria categoria in Categoria.ListaCategorias())
            {
                clbCategorias.Items.Add(categoria);
            }

            // Ajustar tamaños de columnas
            dataGridView1.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            dataGridView1.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

            // Inicializar valores en TextBox
            tbSku.Text = producto.SKU;
            tbNombre.Text = producto.Nombre;
            tbGtin.Text = producto.GTIN;

            dataGridView1.ClearSelection();
        }

        private void btnConfirmar_Click(object sender, EventArgs e)
        {
            bool cambiosRealizados = false;

            // Verificar si los valores principales han sido modificados
            if (tbSku.Text != producto.SKU)
            {
                producto.SKU = tbSku.Text;
                cambiosRealizados = true;
            }

            if (tbNombre.Text != producto.Nombre)
            {
                producto.Nombre = tbNombre.Text;
                cambiosRealizados = true;
            }

            if (tbGtin.Text != producto.GTIN)
            {
                producto.GTIN = tbGtin.Text;
                cambiosRealizados = true;
            }

            // Procesar los cambios realizados en el DataGridView
            foreach (var item in valoresModificados)
            {
                string atributo = item.Key;
                string nuevoValor = item.Value;

                // Actualizar en la base de datos
                // ValorAtributo.ActualizarAtributo(producto.SKU, atributo, nuevoValor);

                cambiosRealizados = true;
            }

            if (cambiosRealizados)
            {
                MessageBox.Show("Cambios realizados correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ResetearEstado();
            }
            else
            {
                MessageBox.Show("No se realizaron cambios.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void ResetearEstado()
        {
            // Refrescar los valores en los controles
            tbSku.Text = producto.SKU;
            tbNombre.Text = producto.Nombre;
            tbGtin.Text = producto.GTIN;

            // Limpiar los valores modificados
            valoresModificados.Clear();
        }

        private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                string atributo = dataGridView1.Rows[e.RowIndex].Cells["Nombre"].Value.ToString(); // Nombre del atributo
                string nuevoValor = dataGridView1.Rows[e.RowIndex].Cells["Tipo"].Value.ToString(); // Nuevo valor

                if (!valoresModificados.ContainsKey(atributo))
                {
                    valoresModificados.Add(atributo, nuevoValor);
                }
                else
                {
                    valoresModificados[atributo] = nuevoValor;
                }
            }
        }

        private void bCancelar_Click(object sender, EventArgs e)
        {
            // Restablecer los valores del DataGridView a su estado original
            dataGridView1.DataSource = ValorAtributo.ListarAtributoDeProducto(producto);

            // Limpiar los valores modificados
            valoresModificados.Clear();

            // Cerrar el formulario
            this.Close();
        }
        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void bConfirmar_Click(object sender, EventArgs e)
        {
            bool cambiosRealizados = false;

            // Verificar si los valores principales han sido modificados
            if (tbSku.Text != producto.SKU)
            {
                producto.SKU = tbSku.Text;
                cambiosRealizados = true;
            }

            if (tbNombre.Text != producto.Nombre)
            {
                producto.Nombre = tbNombre.Text;
                cambiosRealizados = true;
            }

            if (tbGtin.Text != producto.GTIN)
            {
                producto.GTIN = tbGtin.Text;
                cambiosRealizados = true;
            }

            // Procesar los cambios realizados en el DataGridView
            foreach (var item in valoresModificados)
            {
                string atributo = item.Key;
                string nuevoValor = item.Value;

                // Actualizar en la base de datos o en el modelo de datos
                // Aquí debes llamar a tu método de actualización de la base de datos.
                // ValorAtributo.ActualizarAtributo(producto.SKU, atributo, nuevoValor);


                // Asumiendo que tienes un método para actualizar los atributos de Producto
                // Producto.ActualizarAtributo(producto.SKU, atributo, nuevoValor);

                cambiosRealizados = true;
            }

            if (cambiosRealizados)
            {
                MessageBox.Show("Cambios realizados correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ResetearEstado();
            }
            else
            {
                MessageBox.Show("No se realizaron cambios.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }


        }
    }
}

