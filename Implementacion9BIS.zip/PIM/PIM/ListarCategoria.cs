﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIM
{
    public partial class ListarCategoria : Form
    {
        public ListarCategoria()
        {
            InitializeComponent();
        }

        private void ListarCategoria_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = Categoria.ListaCategorias();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && (e.ColumnIndex == dataGridView1.Columns["Editar"].Index || e.ColumnIndex == dataGridView1.Columns["Eliminar"].Index))
            {
                // Obtener el producto correspondiente a la fila seleccionada
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                string categoriaNombre = row.Cells["nombre"].Value.ToString(); // Suponiendo que la columna "Sku" existe en la fuente de datos

                if (e.ColumnIndex == dataGridView1.Columns["Editar"].Index)
                {
                    // Acción para el botón "Editar"
                    MessageBox.Show("Editar Categoria con nombre: " + categoriaNombre);
                    // Aquí puedes abrir un nuevo formulario para editar el producto
                }
                else if (e.ColumnIndex == dataGridView1.Columns["Eliminar"].Index)
                {
                    // Acción para el botón "Eliminar"
                    DialogResult result = MessageBox.Show("¿Estás seguro de que deseas eliminar la  categoria  con nombre: " + categoriaNombre + "?", "Confirmar eliminación", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        // Aquí puedes llamar a una función para eliminar el producto de la base de datos
                        Producto p1 = new Producto();
                        p1.SKU = categoriaNombre;
                        p1.Borrar();
                        // Recargar los datos después de eliminar
                        dataGridView1.DataSource = Producto.ListaProductos();
                    }
                }
            }
        }


    }
}
